# TRÌNH TỰ LESSON — Grammar Worksheet · A1 Movers · Daily Routines & Activities

Mã lesson: GRAM-MOVERS-DAILY-01 · Phiên bản 0.6 · Trạng thái: Nháp
Dùng cùng file Kiến thức (K) và file Task Format (TF) của lesson này.

## S1. Quy mô phiếu
- Bài về nhà, học sinh tự làm, không cần ai giải thích thêm.
- Thời lượng khoảng 25 phút; 6 Task; khoảng 25 câu có đáp án.
- Một phiếu có một trọng tâm ngữ pháp. Mỗi bước có một vai trò khác nhau; không dùng nhiều bài cùng dạng rồi gán thành nhiều bước.
- Không bắt buộc mỗi bước tương ứng một Task.

## S2. Tiêu chí quan trọng nhất
Học sinh phân biệt được thói quen và hành động đang diễn ra dựa trên **ý nghĩa của tình huống**, không chỉ nhìn thấy `usually` hay `now` để chọn thì.

## S3. Trình tự gốc và các bước
Trình tự gốc có bốn mức nhận thức: **Recognition** (nhận diện), **Understanding** (hiểu), **Application** (vận dụng), **Creation** (sáng tạo). Phiếu có năm bước, mức Application tách thành hai bước (vận dụng có kiểm soát, vận dụng trong tình huống):

| Bước | Mức | Tên bước | Task |
|---|---|---|---|
| G1 | Recognition | Quan sát cấu trúc | TF-G1 |
| G2 | Understanding | Hiểu nghĩa và cách dùng | TF-G2 |
| G3 | Application (có kiểm soát) | Luyện có kiểm soát | TF-G3a, TF-G3b |
| G4 | Application (trong tình huống) | Sử dụng trong tình huống | TF-G4 |
| G5 | Creation | Tự diễn đạt | TF-G5 |

Mỗi mã TF có 1 đến 3 phương án thay thế (hậu tố A, B, C). Chọn một phương án mỗi lần tạo phiếu (mặc định G2 là TF-G2-B, vì TF-G2-A cho sẵn dạng động từ nên học sinh có thể chọn đúng nhờ đuôi -ing hay -s, không nhờ hiểu nghĩa), ưu tiên phương án ít dùng gần đây để các phiếu cùng chủ đề không giống nhau. Mọi phương án của một bước phải phục vụ cùng vai trò và cùng tiêu chí kiểm định.

### G1 — Recognition: Quan sát cấu trúc
- Vai trò: học sinh nhận ra hai mẫu câu trong một tình huống có nghĩa; chưa phải làm đúng sai.
- Nội dung: cảnh chính (K3.1), chỉ chứa mẫu mục tiêu.
- Tiêu chí kiểm định:
  1. Học sinh nhận ra cấu trúc mà không phải đoán?
  2. Có động từ nào ngoài hai nhóm mục tiêu làm học sinh phân vân không?
  3. Làm được khi in đen trắng?
  4. Ví dụ tự nhiên và đúng ngữ pháp?

### G2 — Understanding: Hiểu nghĩa và cách dùng
- Vai trò: học sinh phân biệt điều thường làm với điều đang diễn ra bằng nghĩa.
- Nội dung: tình huống ngắn của Tom, Mia và người thân.
- Tiêu chí kiểm định: nếu học sinh không hiểu nghĩa thì có thể chọn đúng chỉ nhờ từ khóa hoặc đuôi -ing không? Đếm số câu thuộc loại đó. Với G2, hai lựa chọn phải khác nhau ở thì, còn thông tin quyết định nằm trong tình huống hoặc câu hỏi.

### G3 — Application (có kiểm soát): Luyện có kiểm soát
- Vai trò: học sinh chọn và tạo đúng hình thức khi đã có đủ gợi ý.
- Nội dung: tình huống ngắn của Tom và Mia; đủ khẳng định, phủ định, câu hỏi; đủ các chủ ngữ trong K4.
- Task: ít nhất một Task nhận diện hình thức (TF-G3a) và một Task tự tạo hình thức (TF-G3b).
- Tiêu chí kiểm định: mỗi câu có đáp án rõ ràng? Bài kiểm đúng quy tắc đang học? Có vô tình đòi từ vựng hay cấu trúc ngoài phạm vi không?

### G4 — Application (trong tình huống): Sử dụng trong tình huống
- Vai trò: học sinh dùng cấu trúc phù hợp với thông tin cho sẵn; phải chọn giữa hai thì để truyền đạt.
- Nội dung: bảng dữ kiện Ben và Lucy (thói quen thứ Bảy, việc đang làm Chủ nhật 3 giờ chiều).
- Tiêu chí kiểm định: học sinh có phải xử lý thông tin để tạo câu không, hay chỉ làm lại bài điền từ của G3?

### G5 — Creation: Tự diễn đạt
- Vai trò: học sinh tự chọn thông tin và dùng cấu trúc đã học.
- Nội dung: thông tin cá nhân, gần gũi đời sống; việc em và một người trong gia đình đang làm.
- Tiêu chí kiểm định: học sinh có thật sự tự chọn thông tin không? Cấu trúc đúng không? Người chấm đánh giá được cả tính chính xác lẫn ý nghĩa không?

## S4. Nhãn chuẩn dùng trên phiếu
| Nhãn | Định nghĩa in trên phiếu |
|---|---|
| Usually | what someone does again and again |
| Now | what someone is doing at this moment |
Chỉ dùng hai nhãn này cho hai khái niệm. Không dùng Habit, Often, Every day làm nhãn. Mọi bảng Usually | Now trên phiếu phải có dòng tiêu đề cột, và định nghĩa in ngay trong ô tiêu đề (ví dụ `Usually (what someone does again and again)`); không để định nghĩa chỉ nằm trong ghi chú.

## S5. Quy tắc toàn phiếu
0. **Từ chỉ thời gian** (dùng để đếm trong quy tắc 1): usually, every + từ, on + ngày, now, at the moment, today, at + giờ, how often, Look!, Listen!.
1. Ít nhất 30% số câu có đáp án trong mỗi Task thuộc G2, G3a và G3b phải xác định được chỉ từ NGHĨA của tình huống. Một câu chỉ được tính khi cả hai điều đúng: (i) câu không chứa từ chỉ thời gian ở mục 0; (ii) câu hoặc lượt thoại liền trước KHÔNG chứa động từ ở đúng dạng của đáp án (xem 1d). Tình huống tả bằng ai ở đâu, cầm hoặc có gì (be + nơi chốn, with + đồ vật), ví dụ "Mia is in the kitchen with flour and eggs." Báo cáo số câu và số thứ tự từng Task. Nếu không đạt 30%, viết lại câu cho đạt trước khi nộp; chỉ ghi "không đạt" khi thật sự không làm được và nêu lý do.
1b. Mỗi câu chọn hoặc điền chỉ có đúng một đáp án. Với mỗi câu, tự thử đáp án còn lại; nếu nó cũng hợp lý trong tình huống thì viết lại câu hoặc thêm thông tin vào tình huống. Không viết câu hỏi nhắc lại việc vừa được nói rõ ở câu trước. Các mẫu thường gây hai đáp án, phải tránh hoặc thêm dấu hiệu:
   - Sau một câu tả cảnh, hỏi "[Does he swim / Is he swimming]?" mà không có dấu hiệu "bây giờ" (thêm "at the moment" hoặc một chi tiết như "He is in the water").
   - "She [feeds / is feeding] it" không có dấu hiệu rõ về lúc này hay thói quen.
   - Câu nói về khả năng như "You swim very fast" (có thể hiểu là khả năng hay đang bơi).
   - Câu phủ định "She doesn't cook / isn't cooking" khi tình huống không nói rõ.
   - Câu điền một từ trong ngoặc mà ngữ cảnh chỉ gợi ý chứ không khẳng định (ví dụ chỉ có cảnh "with a fruit" rồi suy ra "isn't eating").
   - Câu phủ định sau một câu tả cảnh, ví dụ "The boys are in the water. They [don't play / aren't playing] football." (cả hai đều hợp lý).
   - Điền một động từ sau cảnh chỉ có đồ vật, ví dụ "Tom is at his desk with a book. He (read) ____ a story." và "He [draws / is drawing] a monkey" sau "at the desk with his pencils".
   - Câu hỏi nói về người đó trực tiếp với chính người đó bằng ngôi thứ ba ("Tom: What does Mia do? Mia: I read..."), không tự nhiên.
   Khi một đáp án phụ thuộc cảnh trước đó, cảnh phải cho biết trực tiếp vì sao đang diễn ra bây giờ, mà không dùng đúng dạng động từ của đáp án (ví dụ thêm lượt thoại "Where are you?" và câu đáp nêu nơi chốn: "I am in the kitchen.").
1c. Câu "đang làm" dùng hiện tại đơn là sai nội dung bài; việc đang diễn ra luôn dùng am/is/are + V-ing.
1d. Cấm "chép dạng": không viết một câu rồi bắt chọn hoặc điền lại chính câu đó (ví dụ "Mia is reading a story. She [reads / is reading] a story." hoặc "I am playing football now. I ____ football now. (play)"), vì học sinh chỉ chép dạng động từ mà không cần hiểu nghĩa. Câu chọn hoặc điền phải tự mang nghĩa; câu tình huống trước đó nói điều khác (nơi chốn, đồ vật, người cùng hội thoại), không nhắc lại động từ của đáp án.
2. Không dùng màu để phân biệt; phiếu in đen trắng vẫn làm được.
3. Không phụ thuộc vào ảnh hay âm thanh (phiếu này không có).
4. Nhân vật và cảnh theo K3.1; không thêm sự kiện mâu thuẫn.
5. Từ vựng và cấu trúc đúng K4 và K5.
6. Mức hỗ trợ giảm dần từ G3 đến G5: G3 có đủ gợi ý; G4 có dữ kiện nhưng không cho sẵn cấu trúc; G5 có ví dụ nhưng không viết sẵn câu.
